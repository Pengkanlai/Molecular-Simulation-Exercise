#include "system.h"

int NumberOfSteps;
int NumberOfInitializationSteps;
int NumberOfNoseHooverChains;
int Choice;

double Tstep;
double Nu;
double Temperature;
double Position;
double Velocity;
double ConservedEnergy;
double Freqnos;
double OldF;
